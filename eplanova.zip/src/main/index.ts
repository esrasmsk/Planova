import { app, BrowserWindow, Menu, Tray, nativeImage, dialog, shell } from 'electron'
import { join } from 'path'
import { initDb, loadConfig } from './db'
import { registerHandlers } from './handlers'
import { startReminderLoop, stopReminderLoop } from './reminders'

let win: BrowserWindow | null = null
let tray: Tray | null = null
let gercektenCik = false

const tekKopya = app.requestSingleInstanceLock()
if (!tekKopya) app.quit()

// Tepsi simgesi: 16x16 kagit sarisi kare (harici dosya gerekmez)
function trayIcon(): Electron.NativeImage {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32">
    <rect x="3" y="2" width="26" height="28" rx="3" fill="#faf6ea" stroke="#2f3a34" stroke-width="2"/>
    <rect x="3" y="2" width="6" height="28" fill="#c06c52"/>
    <line x1="13" y1="11" x2="25" y2="11" stroke="#4f7d9e" stroke-width="2"/>
    <line x1="13" y1="17" x2="25" y2="17" stroke="#4f7d9e" stroke-width="2"/>
    <line x1="13" y1="23" x2="21" y2="23" stroke="#4f7d9e" stroke-width="2"/>
  </svg>`
  return nativeImage.createFromDataURL(`data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`)
}

function createWindow(): void {
  win = new BrowserWindow({
    width: 1360,
    height: 900,
    minWidth: 1040,
    minHeight: 680,
    show: false,
    backgroundColor: '#2f3a34',
    title: 'Tema Planner',
    icon: trayIcon(),
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false,
      contextIsolation: true,
      nodeIntegration: false
    }
  })

  win.on('ready-to-show', () => win?.show())

  win.on('close', (e) => {
    if (!gercektenCik) {
      e.preventDefault()
      win?.hide()
    }
  })

  win.webContents.setWindowOpenHandler(({ url }) => {
    void shell.openExternal(url)
    return { action: 'deny' }
  })

  if (process.env.ELECTRON_RENDERER_URL) {
    void win.loadURL(process.env.ELECTRON_RENDERER_URL)
  } else {
    void win.loadFile(join(__dirname, '../renderer/index.html'))
  }
}

function createTray(): void {
  tray = new Tray(trayIcon())
  tray.setToolTip('Tema Planner')
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: 'Planneri ac', click: () => showWindow() },
      { type: 'separator' },
      {
        label: 'Windows ile baslat',
        type: 'checkbox',
        checked: app.getLoginItemSettings().openAtLogin,
        click: (item) => app.setLoginItemSettings({ openAtLogin: item.checked, openAsHidden: true })
      },
      { type: 'separator' },
      {
        label: 'Cikis',
        click: () => {
          gercektenCik = true
          app.quit()
        }
      }
    ])
  )
  tray.on('double-click', () => showWindow())
}

function showWindow(): void {
  if (!win) return createWindow()
  if (win.isMinimized()) win.restore()
  win.show()
  win.focus()
}

app.on('second-instance', () => showWindow())

void app.whenReady().then(async () => {
  app.setAppUserModelId('com.temayazilim.planner')
  loadConfig()
  registerHandlers()

  createWindow()
  createTray()
  Menu.setApplicationMenu(null)

  try {
    await initDb()
  } catch (err: any) {
    dialog.showErrorBox(
      'Veritabanina baglanilamadi',
      `${String(err?.message ?? err)}\n\nAyarlar bolumunden baglanti bilgilerini duzeltip "Yeniden baglan" deyin.`
    )
  }

  startReminderLoop(() => win)

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('before-quit', () => {
  gercektenCik = true
  stopReminderLoop()
})

app.on('window-all-closed', () => {
  // tepside calismaya devam eder
})

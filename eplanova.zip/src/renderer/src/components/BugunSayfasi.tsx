import { useEffect, useState } from 'react'
import type { Etiket, Gorev } from '../types'
import { Bos, GorevSatiri } from './Ortak'
import { gunEkle, isoGun } from '../tarih'

interface Props {
  etiketler: Etiket[]
  yenile: number
  onDuzenle: (g: Partial<Gorev> | null) => void
  onDegisti: () => void
}

export default function BugunSayfasi({ etiketler, yenile, onDuzenle, onDegisti }: Props): JSX.Element {
  const [geciken, setGeciken] = useState<Gorev[]>([])
  const [bugun, setBugun] = useState<Gorev[]>([])
  const [yarin, setYarin] = useState<Gorev[]>([])
  const [etiketFiltre, setEtiketFiltre] = useState<number | null>(null)

  useEffect(() => {
    void yukle()
  }, [yenile, etiketFiltre])

  async function yukle(): Promise<void> {
    const b = new Date()
    const bIso = isoGun(b)
    const ortak = etiketFiltre ? { etiketId: etiketFiltre } : {}

    const [gec, bug, yar] = await Promise.all([
      window.api.task.list({ ...ortak, bitis: isoGun(gunEkle(b, -1)), durum: 0 }),
      window.api.task.list({ ...ortak, baslangic: bIso, bitis: bIso }),
      window.api.task.list({ ...ortak, baslangic: isoGun(gunEkle(b, 1)), bitis: isoGun(gunEkle(b, 7)), durum: 0 })
    ])
    setGeciken(gec)
    setBugun(bug)
    setYarin(yar)
  }

  async function tamamla(g: Gorev): Promise<void> {
    await window.api.task.complete(g.ID, g.DURUM !== 1)
    onDegisti()
  }

  async function sil(g: Gorev): Promise<void> {
    if (!confirm(`"${g.BASLIK}" silinsin mi?`)) return
    await window.api.task.remove(g.ID)
    onDegisti()
  }

  const props = { onTamamla: tamamla, onDuzenle, onSil: sil }
  const acikBugun = bugun.filter((g) => g.DURUM === 0)
  const bitenBugun = bugun.filter((g) => g.DURUM === 1)

  return (
    <>
      <div className="secim-seridi" style={{ marginBottom: 6 }}>
        <button className={`secim${etiketFiltre === null ? ' acik' : ''}`} onClick={() => setEtiketFiltre(null)}>
          Tümü
        </button>
        {etiketler.map((e) => (
          <button
            key={e.ID}
            className={`secim${etiketFiltre === e.ID ? ' acik' : ''}`}
            onClick={() => setEtiketFiltre(etiketFiltre === e.ID ? null : e.ID)}
            style={etiketFiltre === e.ID ? { background: e.RENK, borderColor: e.RENK, color: '#fffdf6' } : {}}
          >
            {e.AD}
          </button>
        ))}
      </div>

      {geciken.length > 0 && (
        <>
          <h2 className="bolum-basligi" style={{ color: 'var(--kil)' }}>
            Günü geçmiş
          </h2>
          <ul className="gorev-listesi">
            {geciken.map((g) => (
              <GorevSatiri key={g.ID} gorev={g} tarihGoster {...props} />
            ))}
          </ul>
        </>
      )}

      <h2 className="bolum-basligi">Bugün</h2>
      {acikBugun.length === 0 && bitenBugun.length === 0 ? (
        <Bos metin="Bugün için kayıt yok. Yeni görev ekleyin ya da güne bir not düşün." />
      ) : (
        <ul className="gorev-listesi">
          {acikBugun.map((g) => (
            <GorevSatiri key={g.ID} gorev={g} {...props} />
          ))}
          {bitenBugun.map((g) => (
            <GorevSatiri key={g.ID} gorev={g} {...props} />
          ))}
        </ul>
      )}

      <h2 className="bolum-basligi">Önümüzdeki yedi gün</h2>
      {yarin.length === 0 ? (
        <Bos metin="Bu hafta başka bir şey planlanmamış." />
      ) : (
        <ul className="gorev-listesi">
          {yarin.map((g) => (
            <GorevSatiri key={g.ID} gorev={g} tarihGoster {...props} />
          ))}
        </ul>
      )}
    </>
  )
}

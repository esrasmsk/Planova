import { useEffect, useRef, useState } from 'react'
import { gunEkle, gunMetni, haftaninGunu, isoGun } from '../tarih'

interface Props {
  seciliGun: Date
  setSeciliGun: (d: Date) => void
}

const RUH_HALLERI = [
  { kod: 'iyi', simge: '🙂', ad: 'İyi geçti' },
  { kod: 'yogun', simge: '😵', ad: 'Yoğundu' },
  { kod: 'sakin', simge: '😌', ad: 'Sakindi' },
  { kod: 'zor', simge: '😕', ad: 'Zordu' },
  { kod: 'verimli', simge: '🔥', ad: 'Verimliydi' }
]

export default function GunlukSayfasi({ seciliGun, setSeciliGun }: Props): JSX.Element {
  const [icerik, setIcerik] = useState('')
  const [ruh, setRuh] = useState<string | null>(null)
  const [durum, setDurum] = useState('')
  const ilkYukleme = useRef(true)

  useEffect(() => {
    ilkYukleme.current = true
    void (async () => {
      const n = await window.api.journal.get(isoGun(seciliGun))
      setIcerik(n?.ICERIK ?? '')
      setRuh(n?.RUH_HALI ?? null)
      setDurum(n ? 'Kayıtlı' : '')
      ilkYukleme.current = false
    })()
  }, [seciliGun])

  useEffect(() => {
    if (ilkYukleme.current) return
    setDurum('Yazılıyor…')
    const t = setTimeout(async () => {
      await window.api.journal.save(isoGun(seciliGun), icerik, ruh)
      setDurum(`Kaydedildi · ${new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}`)
    }, 700)
    return () => clearTimeout(t)
  }, [icerik, ruh])

  return (
    <>
      <div className="takvim-ust">
        <button className="dgm" onClick={() => setSeciliGun(gunEkle(seciliGun, -1))} aria-label="Önceki gün">
          ‹
        </button>
        <strong style={{ fontFamily: 'var(--serif)', fontSize: 19, minWidth: 250 }}>
          {gunMetni(seciliGun)} · {haftaninGunu(seciliGun)}
        </strong>
        <button className="dgm" onClick={() => setSeciliGun(gunEkle(seciliGun, 1))} aria-label="Sonraki gün">
          ›
        </button>
        <button className="dgm sessiz" onClick={() => setSeciliGun(new Date())}>
          Bugün
        </button>

        <div className="ruh-seridi" style={{ marginLeft: 'auto' }}>
          {RUH_HALLERI.map((r) => (
            <button
              key={r.kod}
              className={`ruh${ruh === r.kod ? ' secili' : ''}`}
              title={r.ad}
              onClick={() => setRuh(ruh === r.kod ? null : r.kod)}
            >
              {r.simge}
            </button>
          ))}
        </div>
      </div>

      <textarea
        className="gunluk-alan"
        value={icerik}
        maxLength={8000}
        onChange={(e) => setIcerik(e.target.value)}
        placeholder="Bugün ne oldu, kiminle konuştunuz, aklınızda ne kaldı…"
      />

      <p className="bos" style={{ padding: '6px 0', fontSize: 12 }}>
        {durum} · {icerik.length}/8000 karakter
      </p>
    </>
  )
}

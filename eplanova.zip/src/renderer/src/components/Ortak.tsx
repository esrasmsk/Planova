import type { Gorev } from '../types'
import { coz, kalanMetni, saatMetni } from '../tarih'

export function Tik(): JSX.Element {
  return (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
      <path d="M3 8.6 6.3 12 13 4.4" />
    </svg>
  )
}

export function Bos({ metin }: { metin: string }): JSX.Element {
  return <p className="bos">{metin}</p>
}

interface SatirProps {
  gorev: Gorev
  tarihGoster?: boolean
  onTamamla: (g: Gorev) => void
  onDuzenle: (g: Gorev) => void
  onSil: (g: Gorev) => void
}

export function GorevSatiri({ gorev, tarihGoster, onTamamla, onDuzenle, onSil }: SatirProps): JSX.Element {
  const bas = coz(gorev.BASLANGIC)
  const bitti = gorev.DURUM === 1
  const gecikmis = !bitti && bas !== null && bas.getTime() < Date.now()

  return (
    <li className={`gorev${bitti ? ' bitti' : ''}`}>
      <span className={`oncelik o${gorev.ONCELIK}`} aria-hidden="true" />

      <button
        className="kutu"
        onClick={() => onTamamla(gorev)}
        aria-label={bitti ? 'Tamamlandı işaretini kaldır' : 'Tamamlandı olarak işaretle'}
      >
        <Tik />
      </button>

      <span className="saat">{gorev.TUM_GUN ? 'gün' : saatMetni(gorev.BASLANGIC)}</span>

      <div className="gorev-govde">
        <div className="gorev-baslik">{gorev.BASLIK}</div>
        <div className="gorev-alt">
          {tarihGoster && bas && (
            <span>
              {String(bas.getDate()).padStart(2, '0')}.{String(bas.getMonth() + 1).padStart(2, '0')}.
              {bas.getFullYear()}
            </span>
          )}
          {!bitti && bas && <span className={gecikmis ? 'gecikmis' : ''}>{kalanMetni(bas)}</span>}
          {gorev.TEKRAR_TIP !== 'YOK' && <span>tekrarlı</span>}
          {gorev.uyarilar?.length > 0 && <span>{gorev.uyarilar.length} hatırlatma</span>}
          {gorev.etiketler?.map((e) => (
            <span className="rozetcik" key={e.ID}>
              <i className="nokta" style={{ background: e.RENK }} />
              {e.AD}
            </span>
          ))}
          {gorev.DETAY && <span title={gorev.DETAY}>{gorev.DETAY.slice(0, 70)}</span>}
        </div>
      </div>

      <div className="gorev-eylem">
        <button className="dgm sessiz" onClick={() => onDuzenle(gorev)}>
          Düzenle
        </button>
        <button className="dgm sessiz" onClick={() => onSil(gorev)}>
          Sil
        </button>
      </div>
    </li>
  )
}

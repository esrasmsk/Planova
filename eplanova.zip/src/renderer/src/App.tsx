import { useCallback, useEffect, useState } from 'react'
import type { AppConfig, Etiket, Gorev, Sekme } from './types'
import { gunMetni, haftaninGunu } from './tarih'
import BugunSayfasi from './components/BugunSayfasi'
import TakvimSayfasi from './components/TakvimSayfasi'
import GunlukSayfasi from './components/GunlukSayfasi'
import YapiskanPano from './components/YapiskanPano'
import NotlarSayfasi from './components/NotlarSayfasi'
import AramaSayfasi from './components/AramaSayfasi'
import AyarlarSayfasi from './components/AyarlarSayfasi'
import GorevModal from './components/GorevModal'

interface SekmeTanim {
  kod: Sekme
  ad: string
  renk: string
  cizgili: boolean
  marjli: boolean
}

const SEKMELER: SekmeTanim[] = [
  { kod: 'bugun', ad: 'Bugün', renk: 'var(--kil)', cizgili: true, marjli: true },
  { kod: 'takvim', ad: 'Takvim', renk: 'var(--mavi)', cizgili: false, marjli: false },
  { kod: 'gunluk', ad: 'Günlük', renk: 'var(--erik)', cizgili: true, marjli: true },
  { kod: 'yapiskan', ad: 'Pano', renk: 'var(--hardal)', cizgili: false, marjli: false },
  { kod: 'notlar', ad: 'Notlar', renk: 'var(--adaci)', cizgili: false, marjli: false },
  { kod: 'arama', ad: 'Ara', renk: 'var(--zeytin)', cizgili: false, marjli: false },
  { kod: 'ayarlar', ad: 'Ayarlar', renk: '#6d7278', cizgili: false, marjli: false }
]

interface Bildirim {
  anahtar: number
  baslik: string
  kalan: string
  detay: string | null
}

export default function App(): JSX.Element {
  const [sekme, setSekme] = useState<Sekme>('bugun')
  const [seciliGun, setSeciliGun] = useState(new Date())
  const [etiketler, setEtiketler] = useState<Etiket[]>([])
  const [config, setConfig] = useState<AppConfig | null>(null)
  const [ozet, setOzet] = useState({ acik: 0, bugun: 0, geciken: 0 })
  const [yenile, setYenile] = useState(0)
  const [modal, setModal] = useState<Partial<Gorev> | null | false>(false)
  const [bildirimler, setBildirimler] = useState<Bildirim[]>([])

  const tetikle = useCallback(() => setYenile((n) => n + 1), [])

  const etiketleriYenile = useCallback(async () => {
    try {
      setEtiketler(await window.api.tag.list())
    } catch {
      /* baglanti yoksa bos kalsin */
    }
  }, [])

  useEffect(() => {
    void (async () => {
      setConfig(await window.api.config.get())
      await etiketleriYenile()
    })()
  }, [etiketleriYenile])

  useEffect(() => {
    void (async () => {
      try {
        setOzet(await window.api.stats())
      } catch {
        /* yoksay */
      }
    })()
  }, [yenile])

  useEffect(() => {
    const b1 = window.api.onDataChanged(tetikle)
    const b2 = window.api.onReminder((v) => {
      setBildirimler((o) => [
        ...o,
        { anahtar: Date.now() + Math.random(), baslik: v.baslik, kalan: v.kalan, detay: v.detay }
      ])
    })
    return () => {
      b1()
      b2()
    }
  }, [tetikle])

  useEffect(() => {
    const kisayol = (e: KeyboardEvent): void => {
      if (e.ctrlKey && e.key.toLowerCase() === 'n') {
        e.preventDefault()
        setModal(null)
      }
      if (e.ctrlKey && e.key.toLowerCase() === 'f') {
        e.preventDefault()
        setSekme('arama')
      }
    }
    window.addEventListener('keydown', kisayol)
    return () => window.removeEventListener('keydown', kisayol)
  }, [])

  const aktif = SEKMELER.find((s) => s.kod === sekme)!
  const bugunMu = new Date().toDateString() === seciliGun.toDateString()

  const basliklar: Record<Sekme, { h1: string; alt: string }> = {
    bugun: { h1: gunMetni(new Date()), alt: `${haftaninGunu(new Date())} · ${ozet.acik} açık iş` },
    takvim: { h1: 'Takvim', alt: 'Bir güne çift tıklayarak hızlıca görev ekleyin' },
    gunluk: { h1: 'Günlük', alt: bugunMu ? 'Bugünün sayfası' : gunMetni(seciliGun) },
    yapiskan: { h1: 'Pano', alt: 'Kalıcı hatırlatmalar ve dağınık fikirler' },
    notlar: { h1: 'Notlar', alt: 'Kişisel sayfalar ve uzun yazılar' },
    arama: { h1: 'Ara', alt: 'Defterin tamamında arama' },
    ayarlar: { h1: 'Ayarlar', alt: 'Bağlantı, etiketler ve PIN' }
  }

  return (
    <div className="masa">
      <div className="defter">
        <div className="sirt" aria-hidden="true">
          {Array.from({ length: 16 }, (_, i) => (
            <span className="halka" key={i} />
          ))}
        </div>

        <div className="sayfa-yigini">
          <div className="delikler" aria-hidden="true">
            {Array.from({ length: 16 }, (_, i) => (
              <span className="delik" key={i} />
            ))}
          </div>

          <div className={`sayfa${aktif.cizgili ? ' cizgili' : ''}${aktif.marjli ? ' marjli' : ''}`}>
            <header className="sayfa-basi">
              <div>
                <h1>{basliklar[sekme].h1}</h1>
                <p className="altyazi">{basliklar[sekme].alt}</p>
              </div>
              <div className="bas-sag">
                {sekme !== 'ayarlar' && sekme !== 'arama' && (
                  <button className="dgm birincil" onClick={() => setModal(null)}>
                    Görev ekle
                  </button>
                )}
              </div>
            </header>

            <div className="sayfa-govde">
              {sekme === 'bugun' && (
                <BugunSayfasi
                  etiketler={etiketler}
                  yenile={yenile}
                  onDuzenle={(g) => setModal(g)}
                  onDegisti={tetikle}
                />
              )}

              {sekme === 'takvim' && (
                <TakvimSayfasi
                  seciliGun={seciliGun}
                  setSeciliGun={setSeciliGun}
                  yenile={yenile}
                  onDuzenle={(g) => setModal(g)}
                  onDegisti={tetikle}
                />
              )}

              {sekme === 'gunluk' && <GunlukSayfasi seciliGun={seciliGun} setSeciliGun={setSeciliGun} />}

              {sekme === 'yapiskan' && <YapiskanPano yenile={yenile} />}

              {sekme === 'notlar' && <NotlarSayfasi config={config} yenile={yenile} />}

              {sekme === 'arama' && (
                <AramaSayfasi
                  onGunSec={(d) => {
                    setSeciliGun(d)
                    setSekme('takvim')
                  }}
                />
              )}

              {sekme === 'ayarlar' && (
                <AyarlarSayfasi
                  config={config}
                  setConfig={setConfig}
                  etiketler={etiketler}
                  etiketleriYenile={() => void etiketleriYenile()}
                />
              )}
            </div>

            <footer className="durum-cubugu">
              <span>{ozet.acik} açık</span>
              <span>{ozet.bugun} bugün</span>
              {ozet.geciken > 0 && <span style={{ color: 'var(--kil)' }}>{ozet.geciken} gecikmiş</span>}
              <span style={{ marginLeft: 'auto' }}>Ctrl+N yeni görev · Ctrl+F ara</span>
            </footer>
          </div>
        </div>

        <nav className="sekmeler">
          {SEKMELER.map((s) => (
            <button
              key={s.kod}
              className={`sekme${sekme === s.kod ? ' aktif' : ''}`}
              style={{ ['--sekme-renk' as any]: s.renk }}
              onClick={() => setSekme(s.kod)}
            >
              {s.kod === 'bugun' && ozet.geciken > 0 && <span className="rozet">{ozet.geciken}</span>}
              {s.ad}
            </button>
          ))}
        </nav>
      </div>

      {modal !== false && (
        <GorevModal
          gorev={modal}
          varsayilanTarih={seciliGun}
          etiketler={etiketler}
          onKapat={() => setModal(false)}
          onKaydedildi={() => {
            setModal(false)
            tetikle()
          }}
        />
      )}

      {bildirimler.length > 0 && (
        <div className="bildirim-yuvasi">
          {bildirimler.map((b) => (
            <div className="bildirim" key={b.anahtar}>
              <button
                onClick={() => setBildirimler((o) => o.filter((x) => x.anahtar !== b.anahtar))}
                aria-label="Bildirimi kapat"
              >
                ×
              </button>
              <b>{b.baslik}</b>
              {b.detay && <div style={{ fontSize: 14 }}>{b.detay.slice(0, 110)}</div>}
              <small>{b.kalan}</small>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
